import os
import re
import time
import pandas as pd
import streamlit as st
import markdown
import google.generativeai as genai
from googleapiclient.discovery import build
from youtube_transcript_api import YouTubeTranscriptApi, TranscriptsDisabled, NoTranscriptFound
import requests

# ---------------------- CONFIG ----------------------
YOUTUBE_API_KEY = st.secrets.get("YOUTUBE_API_KEY")
GEMINI_API_KEY = st.secrets.get("GEMINI_API_KEY")
CLAUDE_API_KEY = st.secrets.get("CLAUDE_API_KEY")

missing_keys = []
if not YOUTUBE_API_KEY:
    missing_keys.append("YOUTUBE_API_KEY")
if not GEMINI_API_KEY:
    missing_keys.append("GEMINI_API_KEY")
if not CLAUDE_API_KEY:
    missing_keys.append("CLAUDE_API_KEY")

if missing_keys:
    st.error(f"Missing required API keys: {', '.join(missing_keys)}. Please check your Streamlit secrets.")
    st.stop()

genai.configure(api_key=GEMINI_API_KEY)
youtube = build("youtube", "v3", developerKey=YOUTUBE_API_KEY)

# ---------------------- HELPERS ----------------------
def extract_video_id(url):
    match = re.search(r"(?:v=|/)([0-9A-Za-z_-]{11})", url)
    return match.group(1) if match else None

def get_video_title(video_id):
    try:
        resp = youtube.videos().list(part="snippet", id=video_id).execute()
        if resp.get("items"):
            return re.sub(r'[\\/*?:"<>|]', "_", resp["items"][0]["snippet"]["title"])
    except Exception as e:
        st.warning(f"Error fetching title: {e}")
    return "Untitled"

def get_comments(video_id):
    comments = []
    seen = set()
    token = None
    try:
        while True:
            resp = youtube.commentThreads().list(
                part="snippet", videoId=video_id, maxResults=100, pageToken=token, textFormat="plainText"
            ).execute()
            for item in resp.get("items", []):
                txt = item["snippet"]["topLevelComment"]["snippet"]["textDisplay"].strip()
                if txt and txt not in seen:
                    comments.append(txt)
                    seen.add(txt)
                    if len(comments) >= 3000:
                        return comments
            token = resp.get("nextPageToken")
            if not token:
                break
            time.sleep(0.1)
        return comments
    except Exception:
        st.error("⚠️ We couldn't retrieve comments for this video. It may have them disabled or restricted.")
        return []

def get_transcript(video_id):
    try:
        transcript = YouTubeTranscriptApi.get_transcript(video_id, languages=['en'])
        return " ".join([entry['text'] for entry in transcript])
    except (TranscriptsDisabled, NoTranscriptFound):
        st.error("⚠️ No English transcript is available for this video.")
        return None
    except Exception:
        st.error("⚠️ We couldn’t fetch the transcript for this video. YouTube may have restricted access.")
        return None

def call_claude(prompt):
    headers = {
        "Authorization": f"Bearer {CLAUDE_API_KEY}",
        "HTTP-Referer": "https://streamlit.io",
        "X-Title": "YouTube Analyzer",
        "Content-Type": "application/json"
    }
    data = {
        "model": "anthropic/claude-3-haiku",
        "messages": [{"role": "user", "content": prompt}]
    }
    try:
        res = requests.post("https://openrouter.ai/api/v1/chat/completions", headers=headers, json=data)
        result = res.json()
        if "choices" in result and result["choices"]:
            return result["choices"][0]["message"]["content"]
        else:
            st.warning("Claude API error: " + result.get("error", {}).get("message", "Unknown error"))
            return ""
    except Exception as e:
        st.warning("Claude API exception: " + str(e))
        return ""

def analyze_comments(all_comments, model_choice):
    prompt_prefix = (
        "You are a psychological research assistant. Your task is to read user comments\n"
        "and extract key emotional or psychological challenges. Group comments into 4–8 categories.\n\n"
        "Only include categories that reflect meaningful emotional or psychological experiences.\n"
        "Do NOT include gratitude-only categories unless they hint at deeper pain or healing."
    )
    MAX_TOKENS = 8000
    i = 0
    chunk = 0
    n = len(all_comments)
    output_area = st.empty()
    progress = st.progress(0)
    cost_tracker = st.empty()
    total_input_tokens = 0
    total_output_tokens = 0
    while i < n:
        batch = []
        tokens = 0
        while i < n and tokens < MAX_TOKENS:
            c = all_comments[i]
            word_count = len(c.split())
            if tokens + word_count > MAX_TOKENS:
                break
            batch.append(c)
            tokens += word_count
            i += 1
        chunk += 1
        batch_comments = "\n\n".join(f"- {c}" for c in batch)
        prompt = f"""Previous analysis:
{prompt_prefix}

New YouTube comment batch:
{batch_comments}

Update the emotional analysis. Group comments into 4–8 categories.

For each category, use this exact format:

### [CATEGORY TITLE]

**Description:** A short 1–2 sentence summary

**Example Comments:**

- Comment 1

- Comment 2

- Comment 3

(add a blank line between each bullet)

**YouTube Title Ideas:**

- Title idea 1

- Title idea 2

- Title idea 3

(add a blank line between each bullet)

Only include categories that reflect meaningful emotional or psychological experiences.
Do NOT include gratitude-only categories unless they hint at deeper pain or healing.

At the end of the analysis, include a section titled **Content Gaps & Opportunities**:

- List any major emotional or psychological themes that were underrepresented

- Suggest powerful new video ideas based on those gaps

- Keep ideas concise, curiosity-driven, and aligned with audience needs
"""
        try:
            if model_choice == "Claude":
                response = call_claude(prompt)
            else:
                model = genai.GenerativeModel("gemini-1.5-pro")
                response = model.generate_content(prompt).text.strip()
            input_tokens = tokens * 1.3
            output_tokens = len(response.split()) * 1.3
            total_input_tokens += input_tokens
            total_output_tokens += output_tokens
            cost = 0
            if model_choice == "Claude":
                cost = (input_tokens / 1_000_000) * 0.25 + (output_tokens / 1_000_000) * 1.25
            else:
                cost = (input_tokens / 1_000_000) * 0.125 + (output_tokens / 1_000_000) * 0.375
            cost_tracker.info(f"Estimated cost so far: ${cost:.4f}")
            prompt_prefix = response.strip()
            output_area.info(f"Processed chunk {chunk} ({i}/{n} comments)")
        except Exception:
            st.warning(f"Due to {model_choice} API limits, only {i} out of {n} comments were processed.")
            break
        progress.progress(min(i / n, 1.0))
    return prompt_prefix

def analyze_transcript(transcript_text, model_choice):
    prompt = (
        "You are a content strategist. Analyze the following YouTube transcript to explain why the video might have performed well.\n\n"
        "Provide insights about:\n"
        "- Emotional tone and relatability\n"
        "- Engagement techniques (hooks, pacing, storytelling)\n"
        "- Viewer resonance (what emotions or beliefs are triggered)\n"
        "- Content structure (clarity, flow, novelty)\n\n"
        "Then add a clearly marked final section titled:\n"
        "**Content Gaps & Opportunities**\n"
        "- List missing emotional angles or questions raised in comments\n"
        "- Suggest powerful, curiosity-driven YouTube video ideas\n"
        "- Use bullet points with line breaks between items\n\n"
        f"Transcript:\n{transcript_text}"
    )
    try:
        if model_choice == "Claude":
            return call_claude(prompt)
        else:
            model = genai.GenerativeModel("gemini-1.5-pro")
            return model.generate_content(prompt).text.strip()
    except Exception:
        st.warning(f"Due to {model_choice} API limits, transcript analysis could not be completed.")
        return ""

# ---------------------- STREAMLIT UI ----------------------
st.title("Your AI Psychological Research Assistant - Deep YouTube Audience & Content Insights")

urls_input = st.text_area("Enter up to 2 (!) YouTube URLs (one per line):")
mode = st.radio("Choose analysis type:", ["Comments Only", "Transcript Only", "Both"])
model_choice = st.radio("Choose AI Model:", ["Gemini", "Claude"])

if st.button("Run Analysis"):
    urls = [u.strip() for u in urls_input.strip().splitlines() if u.strip()][:10]
    if not urls:
        st.warning("Please enter at least one valid YouTube URL.")
        st.stop()

    for url in urls:
        vid = extract_video_id(url)
        if not vid:
            st.warning(f"Invalid URL: {url}")
            continue
        title = get_video_title(vid)
        st.header(f"📺 {title}")

        comments_csv = None
        comment_result = None
        transcript_result = None

        if mode in ("Comments Only", "Both"):
            st.subheader("💬 Analyzing Comments")
            cmts = get_comments(vid)
            st.write(f"➡️ {len(cmts)} comments scraped.")
            comments_csv = pd.DataFrame({"comment": cmts}).to_csv(index=False).encode("utf-8")
            with st.spinner(f"Analyzing comments with {model_choice}..."):
                comment_result = analyze_comments(cmts, model_choice)
                st.markdown(markdown.markdown(comment_result), unsafe_allow_html=True)

        if mode in ("Transcript Only", "Both"):
            st.subheader("📜 Analyzing Transcript")
            transcript = get_transcript(vid)
            if transcript:
                with st.spinner(f"Analyzing transcript with {model_choice}..."):
                    transcript_result = analyze_transcript(transcript, model_choice)
                    st.markdown(markdown.markdown(transcript_result), unsafe_allow_html=True)
            else:
                st.error("No English transcript available for this video.")

        # ---------------------- Downloads ----------------------
        st.subheader("📥 Downloads")
        if comments_csv:
            st.download_button("Download Comments CSV", comments_csv, file_name=f"{title}_comments.csv")
        if comment_result:
            st.download_button("Download Comment Analysis", comment_result, file_name=f"{title}_comment_analysis.txt")
        if transcript_result:
            st.download_button("Download Transcript Analysis", transcript_result, file_name=f"{title}_transcript_analysis.txt")
