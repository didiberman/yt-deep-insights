# YouTube Comment Analyzer (Streamlit + Gemini)

This app scrapes YouTube comments and performs emotional/psychological analysis using Google's Gemini API.

## Setup

1. Add your API keys:
   - `YOUTUBE_API_KEY`
   - `GEMINI_API_KEY`

Set these as environment variables or use `.streamlit/secrets.toml` for Streamlit Cloud.

## Run locally
```bash
pip install -r requirements.txt
streamlit run streamlit_app.py
